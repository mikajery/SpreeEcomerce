# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.34-MariaDB)
# Database: mercstud_aji
# Generation Time: 2014-05-08 16:20:00 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table schema_migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `schema_migrations`;

CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;

INSERT INTO `schema_migrations` (`version`)
VALUES
	('20140424092932'),
	('20140424092933'),
	('20140424092934'),
	('20140424092935'),
	('20140424092936'),
	('20140424092937'),
	('20140424092938'),
	('20140424092939'),
	('20140424092940'),
	('20140424092941'),
	('20140424092942'),
	('20140424092943'),
	('20140424092944'),
	('20140424092945'),
	('20140424092946'),
	('20140424092947'),
	('20140424092948'),
	('20140424092949'),
	('20140424092950'),
	('20140424092951'),
	('20140424092952'),
	('20140424092953'),
	('20140424092954'),
	('20140424092955'),
	('20140424092956'),
	('20140424092957'),
	('20140424092958'),
	('20140424092959'),
	('20140424092960'),
	('20140424092961'),
	('20140424092962'),
	('20140424092963'),
	('20140424092964'),
	('20140424092965'),
	('20140424092966'),
	('20140424092967'),
	('20140424092968'),
	('20140424092969'),
	('20140424092970'),
	('20140424092971'),
	('20140424092972'),
	('20140424092973'),
	('20140424092974'),
	('20140424092975'),
	('20140424092976'),
	('20140424092977'),
	('20140424092978'),
	('20140424092979'),
	('20140424092980'),
	('20140424092981'),
	('20140424092982'),
	('20140424092983'),
	('20140424092984'),
	('20140424092985'),
	('20140424092986'),
	('20140424092987'),
	('20140424092988'),
	('20140424092989'),
	('20140424092990'),
	('20140424092991'),
	('20140424092992'),
	('20140424092993'),
	('20140424092994'),
	('20140424092995'),
	('20140424092996'),
	('20140424092997'),
	('20140424092998'),
	('20140424092999'),
	('20140424093000'),
	('20140424093001'),
	('20140424093002'),
	('20140424093003'),
	('20140424093004'),
	('20140424093005'),
	('20140424093006'),
	('20140424093007'),
	('20140424093008'),
	('20140424093009'),
	('20140424093010'),
	('20140424093011'),
	('20140424093012'),
	('20140424093013'),
	('20140424093014'),
	('20140424093015'),
	('20140424093016'),
	('20140424093017'),
	('20140424093018'),
	('20140424093019'),
	('20140424093020'),
	('20140424093021'),
	('20140424093022'),
	('20140424093023'),
	('20140424093024'),
	('20140424093025'),
	('20140424093026'),
	('20140424093027'),
	('20140424093028'),
	('20140424093029'),
	('20140424093030'),
	('20140424093031'),
	('20140424093032'),
	('20140424093033'),
	('20140424093034'),
	('20140424093035'),
	('20140424093036'),
	('20140424093037'),
	('20140424093038'),
	('20140424093039'),
	('20140424093040'),
	('20140424093041'),
	('20140424093042'),
	('20140424093043'),
	('20140424093044'),
	('20140424093045'),
	('20140424093046'),
	('20140424093047'),
	('20140424093048'),
	('20140424093049'),
	('20140424093050'),
	('20140424093051'),
	('20140424093052'),
	('20140424093053'),
	('20140424093054'),
	('20140424093055'),
	('20140424093056'),
	('20140424093057'),
	('20140424093058'),
	('20140424093059'),
	('20140424093060'),
	('20140424093061'),
	('20140424093062'),
	('20140424093063'),
	('20140424093064'),
	('20140424093065'),
	('20140424093066'),
	('20140424093067'),
	('20140424093068'),
	('20140424093069'),
	('20140424093070'),
	('20140424093071'),
	('20140424093072'),
	('20140424093073'),
	('20140424093074'),
	('20140424093075'),
	('20140428101138'),
	('20140428104930'),
	('20140428104931'),
	('20140428104932'),
	('20140428104933'),
	('20140428104934'),
	('20140428104935'),
	('20140428104936'),
	('20140428104937'),
	('20140428104938'),
	('20140428104939'),
	('20140508082425'),
	('20140508082426'),
	('20140508125139');

/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_addresses
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_addresses`;

CREATE TABLE `spree_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `state_name` varchar(255) DEFAULT NULL,
  `alternative_phone` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_addresses_on_firstname` (`firstname`),
  KEY `index_addresses_on_lastname` (`lastname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_adjustments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_adjustments`;

CREATE TABLE `spree_adjustments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_id` int(11) DEFAULT NULL,
  `source_type` varchar(255) DEFAULT NULL,
  `adjustable_id` int(11) DEFAULT NULL,
  `adjustable_type` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `mandatory` tinyint(1) DEFAULT NULL,
  `eligible` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `included` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_adjustments_on_order_id` (`adjustable_id`),
  KEY `index_spree_adjustments_on_source_type_and_source_id` (`source_type`,`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_assets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_assets`;

CREATE TABLE `spree_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `viewable_id` int(11) DEFAULT NULL,
  `viewable_type` varchar(255) DEFAULT NULL,
  `attachment_width` int(11) DEFAULT NULL,
  `attachment_height` int(11) DEFAULT NULL,
  `attachment_file_size` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `attachment_content_type` varchar(255) DEFAULT NULL,
  `attachment_file_name` varchar(255) DEFAULT NULL,
  `type` varchar(75) DEFAULT NULL,
  `attachment_updated_at` datetime DEFAULT NULL,
  `alt` text,
  PRIMARY KEY (`id`),
  KEY `index_assets_on_viewable_id` (`viewable_id`),
  KEY `index_assets_on_viewable_type_and_type` (`viewable_type`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_calculators
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_calculators`;

CREATE TABLE `spree_calculators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `calculable_id` int(11) DEFAULT NULL,
  `calculable_type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_calculators_on_id_and_type` (`id`,`type`),
  KEY `index_spree_calculators_on_calculable_id_and_calculable_type` (`calculable_id`,`calculable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_calculators` WRITE;
/*!40000 ALTER TABLE `spree_calculators` DISABLE KEYS */;

INSERT INTO `spree_calculators` (`id`, `type`, `calculable_id`, `calculable_type`, `created_at`, `updated_at`)
VALUES
	(1,'Spree::Calculator::DefaultTax',1,'Spree::TaxRate','2014-05-08 16:15:51','2014-05-08 16:15:51'),
	(2,'Spree::Calculator::DefaultTax',2,'Spree::TaxRate','2014-05-08 16:16:34','2014-05-08 16:16:34');

/*!40000 ALTER TABLE `spree_calculators` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_client_accounts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_client_accounts`;

CREATE TABLE `spree_client_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `credit_duration` int(11) DEFAULT NULL,
  `credit_limit` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `tel1` varchar(20) DEFAULT NULL,
  `fax1` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `address1` varchar(500) DEFAULT NULL,
  `address2` varchar(500) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_client_accounts` WRITE;
/*!40000 ALTER TABLE `spree_client_accounts` DISABLE KEYS */;

INSERT INTO `spree_client_accounts` (`id`, `name`, `credit_duration`, `credit_limit`, `created_at`, `updated_at`, `tel1`, `fax1`, `email`, `contact_person`, `address1`, `address2`, `city`, `state`, `country`)
VALUES
	(3,'abc',125,60000,'2014-05-08 10:39:03','2014-05-08 14:18:53','','','','lll','','','','','my'),
	(4,'abc abc',30,10000,'2014-05-08 10:48:42','2014-05-08 10:48:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(5,'aaaa ccc',20,30,'2014-05-08 12:25:22','2014-05-08 14:05:03','','','','aaa','','','','selangor','my'),
	(6,'cccc',11,22,'2014-05-08 12:27:16','2014-05-08 12:27:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(9,'aaaa coasta coasta',30,5000,'2014-05-08 14:00:33','2014-05-08 14:21:04','','','','dcdscsd','','','','','cr'),
	(10,'cccxc xzcx',22,33,'2014-05-08 14:19:22','2014-05-08 14:19:22','','','','bbb','','','','','my');

/*!40000 ALTER TABLE `spree_client_accounts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_configurations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_configurations`;

CREATE TABLE `spree_configurations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_configurations_on_name_and_type` (`name`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_countries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_countries`;

CREATE TABLE `spree_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iso_name` varchar(255) DEFAULT NULL,
  `iso` varchar(255) DEFAULT NULL,
  `iso3` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `numcode` int(11) DEFAULT NULL,
  `states_required` tinyint(1) DEFAULT '0',
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_countries` WRITE;
/*!40000 ALTER TABLE `spree_countries` DISABLE KEYS */;

INSERT INTO `spree_countries` (`id`, `iso_name`, `iso`, `iso3`, `name`, `numcode`, `states_required`, `updated_at`)
VALUES
	(1,'CHAD','TD','TCD','Chad',148,0,'2014-05-08 16:06:22'),
	(2,'FAROE ISLANDS','FO','FRO','Faroe Islands',234,0,'2014-05-08 16:06:22'),
	(3,'INDIA','IN','IND','India',356,1,'2014-05-08 16:06:22'),
	(4,'NICARAGUA','NI','NIC','Nicaragua',558,0,'2014-05-08 16:06:22'),
	(5,'SAINT LUCIA','LC','LCA','Saint Lucia',662,0,'2014-05-08 16:06:22'),
	(6,'FIJI','FJ','FJI','Fiji',242,0,'2014-05-08 16:06:22'),
	(7,'INDONESIA','ID','IDN','Indonesia',360,0,'2014-05-08 16:06:22'),
	(8,'NIGER','NE','NER','Niger',562,0,'2014-05-08 16:06:22'),
	(9,'SAINT PIERRE AND MIQUELON','PM','SPM','Saint Pierre and Miquelon',666,0,'2014-05-08 16:06:22'),
	(10,'FINLAND','FI','FIN','Finland',246,0,'2014-05-08 16:06:22'),
	(11,'NIGERIA','NG','NGA','Nigeria',566,1,'2014-05-08 16:06:22'),
	(12,'SAINT VINCENT AND THE GRENADINES','VC','VCT','Saint Vincent and the Grenadines',670,0,'2014-05-08 16:06:22'),
	(13,'FRANCE','FR','FRA','France',250,0,'2014-05-08 16:06:22'),
	(14,'IRAN, ISLAMIC REPUBLIC OF','IR','IRN','Iran, Islamic Republic of',364,0,'2014-05-08 16:06:22'),
	(15,'NIUE','NU','NIU','Niue',570,0,'2014-05-08 16:06:22'),
	(16,'SAMOA','WS','WSM','Samoa',882,0,'2014-05-08 16:06:22'),
	(17,'FRENCH GUIANA','GF','GUF','French Guiana',254,0,'2014-05-08 16:06:22'),
	(18,'IRAQ','IQ','IRQ','Iraq',368,1,'2014-05-08 16:06:22'),
	(19,'SAN MARINO','SM','SMR','San Marino',674,0,'2014-05-08 16:06:22'),
	(20,'IRELAND','IE','IRL','Ireland',372,0,'2014-05-08 16:06:22'),
	(21,'SAO TOME AND PRINCIPE','ST','STP','Sao Tome and Principe',678,0,'2014-05-08 16:06:22'),
	(22,'ISRAEL','IL','ISR','Israel',376,0,'2014-05-08 16:06:22'),
	(23,'SAUDI ARABIA','SA','SAU','Saudi Arabia',682,0,'2014-05-08 16:06:22'),
	(24,'ITALY','IT','ITA','Italy',380,0,'2014-05-08 16:06:22'),
	(25,'SENEGAL','SN','SEN','Senegal',686,0,'2014-05-08 16:06:22'),
	(26,'JAMAICA','JM','JAM','Jamaica',388,0,'2014-05-08 16:06:22'),
	(27,'JAPAN','JP','JPN','Japan',392,0,'2014-05-08 16:06:22'),
	(28,'JORDAN','JO','JOR','Jordan',400,0,'2014-05-08 16:06:22'),
	(29,'BELGIUM','BE','BEL','Belgium',56,0,'2014-05-08 16:06:22'),
	(30,'BELIZE','BZ','BLZ','Belize',84,0,'2014-05-08 16:06:22'),
	(31,'KAZAKHSTAN','KZ','KAZ','Kazakhstan',398,0,'2014-05-08 16:06:22'),
	(32,'UGANDA','UG','UGA','Uganda',800,0,'2014-05-08 16:06:22'),
	(33,'BENIN','BJ','BEN','Benin',204,0,'2014-05-08 16:06:22'),
	(34,'KENYA','KE','KEN','Kenya',404,0,'2014-05-08 16:06:22'),
	(35,'UKRAINE','UA','UKR','Ukraine',804,0,'2014-05-08 16:06:22'),
	(36,'BERMUDA','BM','BMU','Bermuda',60,0,'2014-05-08 16:06:22'),
	(37,'KIRIBATI','KI','KIR','Kiribati',296,0,'2014-05-08 16:06:22'),
	(38,'MEXICO','MX','MEX','Mexico',484,1,'2014-05-08 16:06:22'),
	(39,'UNITED ARAB EMIRATES','AE','ARE','United Arab Emirates',784,1,'2014-05-08 16:06:22'),
	(40,'BHUTAN','BT','BTN','Bhutan',64,0,'2014-05-08 16:06:22'),
	(41,'CUBA','CU','CUB','Cuba',192,0,'2014-05-08 16:06:22'),
	(42,'KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF','KP','PRK','North Korea',408,0,'2014-05-08 16:06:22'),
	(43,'MICRONESIA, FEDERATED STATES OF','FM','FSM','Micronesia, Federated States of',583,1,'2014-05-08 16:06:22'),
	(44,'UNITED KINGDOM','GB','GBR','United Kingdom',826,0,'2014-05-08 16:06:22'),
	(45,'BOLIVIA','BO','BOL','Bolivia',68,0,'2014-05-08 16:06:22'),
	(46,'CYPRUS','CY','CYP','Cyprus',196,0,'2014-05-08 16:06:22'),
	(47,'KOREA, REPUBLIC OF','KR','KOR','South Korea',410,0,'2014-05-08 16:06:22'),
	(48,'MOLDOVA, REPUBLIC OF','MD','MDA','Moldova, Republic of',498,0,'2014-05-08 16:06:22'),
	(49,'UNITED STATES','US','USA','United States',840,1,'2014-05-08 16:06:22'),
	(50,'BOSNIA AND HERZEGOVINA','BA','BIH','Bosnia and Herzegovina',70,0,'2014-05-08 16:06:22'),
	(51,'CZECH REPUBLIC','CZ','CZE','Czech Republic',203,0,'2014-05-08 16:06:22'),
	(52,'KUWAIT','KW','KWT','Kuwait',414,0,'2014-05-08 16:06:22'),
	(53,'MONACO','MC','MCO','Monaco',492,0,'2014-05-08 16:06:22'),
	(54,'URUGUAY','UY','URY','Uruguay',858,0,'2014-05-08 16:06:22'),
	(55,'BOTSWANA','BW','BWA','Botswana',72,0,'2014-05-08 16:06:22'),
	(56,'DENMARK','DK','DNK','Denmark',208,0,'2014-05-08 16:06:22'),
	(57,'GUADELOUPE','GP','GLP','Guadeloupe',312,0,'2014-05-08 16:06:22'),
	(58,'KYRGYZSTAN','KG','KGZ','Kyrgyzstan',417,0,'2014-05-08 16:06:22'),
	(59,'MONGOLIA','MN','MNG','Mongolia',496,0,'2014-05-08 16:06:22'),
	(60,'PHILIPPINES','PH','PHL','Philippines',608,0,'2014-05-08 16:06:22'),
	(61,'BRAZIL','BR','BRA','Brazil',76,1,'2014-05-08 16:06:22'),
	(62,'DJIBOUTI','DJ','DJI','Djibouti',262,0,'2014-05-08 16:06:22'),
	(63,'GUAM','GU','GUM','Guam',316,0,'2014-05-08 16:06:22'),
	(64,'LAO PEOPLE\'S DEMOCRATIC REPUBLIC','LA','LAO','Lao People\'s Democratic Republic',418,0,'2014-05-08 16:06:22'),
	(65,'MONTSERRAT','MS','MSR','Montserrat',500,0,'2014-05-08 16:06:22'),
	(66,'PITCAIRN','PN','PCN','Pitcairn',612,0,'2014-05-08 16:06:22'),
	(67,'UZBEKISTAN','UZ','UZB','Uzbekistan',860,0,'2014-05-08 16:06:22'),
	(68,'BRUNEI DARUSSALAM','BN','BRN','Brunei Darussalam',96,0,'2014-05-08 16:06:22'),
	(69,'DOMINICA','DM','DMA','Dominica',212,0,'2014-05-08 16:06:22'),
	(70,'GUATEMALA','GT','GTM','Guatemala',320,0,'2014-05-08 16:06:22'),
	(71,'MOROCCO','MA','MAR','Morocco',504,0,'2014-05-08 16:06:22'),
	(72,'POLAND','PL','POL','Poland',616,0,'2014-05-08 16:06:22'),
	(73,'VANUATU','VU','VUT','Vanuatu',548,0,'2014-05-08 16:06:22'),
	(74,'DOMINICAN REPUBLIC','DO','DOM','Dominican Republic',214,0,'2014-05-08 16:06:22'),
	(75,'MOZAMBIQUE','MZ','MOZ','Mozambique',508,0,'2014-05-08 16:06:22'),
	(76,'PORTUGAL','PT','PRT','Portugal',620,0,'2014-05-08 16:06:22'),
	(77,'SUDAN','SD','SDN','Sudan',736,1,'2014-05-08 16:06:22'),
	(78,'VENEZUELA','VE','VEN','Venezuela',862,1,'2014-05-08 16:06:22'),
	(79,'ECUADOR','EC','ECU','Ecuador',218,0,'2014-05-08 16:06:22'),
	(80,'GUINEA','GN','GIN','Guinea',324,0,'2014-05-08 16:06:22'),
	(81,'MYANMAR','MM','MMR','Myanmar',104,0,'2014-05-08 16:06:22'),
	(82,'PUERTO RICO','PR','PRI','Puerto Rico',630,0,'2014-05-08 16:06:22'),
	(83,'SURINAME','SR','SUR','Suriname',740,0,'2014-05-08 16:06:22'),
	(84,'VIET NAM','VN','VNM','Viet Nam',704,0,'2014-05-08 16:06:22'),
	(85,'EGYPT','EG','EGY','Egypt',818,0,'2014-05-08 16:06:22'),
	(86,'GUINEA-BISSAU','GW','GNB','Guinea-Bissau',624,0,'2014-05-08 16:06:22'),
	(87,'NAMIBIA','NA','NAM','Namibia',516,0,'2014-05-08 16:06:22'),
	(88,'QATAR','QA','QAT','Qatar',634,0,'2014-05-08 16:06:22'),
	(89,'SVALBARD AND JAN MAYEN','SJ','SJM','Svalbard and Jan Mayen',744,0,'2014-05-08 16:06:22'),
	(90,'EL SALVADOR','SV','SLV','El Salvador',222,0,'2014-05-08 16:06:22'),
	(91,'GUYANA','GY','GUY','Guyana',328,0,'2014-05-08 16:06:22'),
	(92,'REUNION','RE','REU','Reunion',638,0,'2014-05-08 16:06:22'),
	(93,'HAITI','HT','HTI','Haiti',332,0,'2014-05-08 16:06:22'),
	(94,'ROMANIA','RO','ROM','Romania',642,0,'2014-05-08 16:06:22'),
	(95,'SWAZILAND','SZ','SWZ','Swaziland',748,0,'2014-05-08 16:06:22'),
	(96,'HOLY SEE (VATICAN CITY STATE)','VA','VAT','Holy See (Vatican City State)',336,0,'2014-05-08 16:06:22'),
	(97,'RUSSIAN FEDERATION','RU','RUS','Russian Federation',643,1,'2014-05-08 16:06:22'),
	(98,'SWEDEN','SE','SWE','Sweden',752,0,'2014-05-08 16:06:22'),
	(99,'HONDURAS','HN','HND','Honduras',340,0,'2014-05-08 16:06:22'),
	(100,'RWANDA','RW','RWA','Rwanda',646,0,'2014-05-08 16:06:22'),
	(101,'SWITZERLAND','CH','CHE','Switzerland',756,0,'2014-05-08 16:06:22'),
	(102,'HONG KONG','HK','HKG','Hong Kong',344,0,'2014-05-08 16:06:22'),
	(103,'SYRIAN ARAB REPUBLIC','SY','SYR','Syrian Arab Republic',760,0,'2014-05-08 16:06:22'),
	(104,'TAIWAN, PROVINCE OF CHINA','TW','TWN','Taiwan',158,0,'2014-05-08 16:06:22'),
	(105,'TAJIKISTAN','TJ','TJK','Tajikistan',762,0,'2014-05-08 16:06:22'),
	(106,'TANZANIA, UNITED REPUBLIC OF','TZ','TZA','Tanzania, United Republic of',834,0,'2014-05-08 16:06:22'),
	(107,'ARMENIA','AM','ARM','Armenia',51,0,'2014-05-08 16:06:22'),
	(108,'ARUBA','AW','ABW','Aruba',533,0,'2014-05-08 16:06:22'),
	(109,'AUSTRALIA','AU','AUS','Australia',36,1,'2014-05-08 16:06:22'),
	(110,'THAILAND','TH','THA','Thailand',764,0,'2014-05-08 16:06:23'),
	(111,'AUSTRIA','AT','AUT','Austria',40,0,'2014-05-08 16:06:23'),
	(112,'MADAGASCAR','MG','MDG','Madagascar',450,0,'2014-05-08 16:06:23'),
	(113,'TOGO','TG','TGO','Togo',768,0,'2014-05-08 16:06:23'),
	(114,'AZERBAIJAN','AZ','AZE','Azerbaijan',31,0,'2014-05-08 16:06:23'),
	(115,'CHILE','CL','CHL','Chile',152,0,'2014-05-08 16:06:23'),
	(116,'MALAWI','MW','MWI','Malawi',454,0,'2014-05-08 16:06:23'),
	(117,'TOKELAU','TK','TKL','Tokelau',772,0,'2014-05-08 16:06:23'),
	(118,'BAHAMAS','BS','BHS','Bahamas',44,0,'2014-05-08 16:06:23'),
	(119,'CHINA','CN','CHN','China',156,0,'2014-05-08 16:06:23'),
	(120,'MALAYSIA','MY','MYS','Malaysia',458,1,'2014-05-08 16:09:05'),
	(121,'TONGA','TO','TON','Tonga',776,0,'2014-05-08 16:06:23'),
	(122,'BAHRAIN','BH','BHR','Bahrain',48,0,'2014-05-08 16:06:23'),
	(123,'COLOMBIA','CO','COL','Colombia',170,0,'2014-05-08 16:06:23'),
	(124,'MALDIVES','MV','MDV','Maldives',462,0,'2014-05-08 16:06:23'),
	(125,'TRINIDAD AND TOBAGO','TT','TTO','Trinidad and Tobago',780,0,'2014-05-08 16:06:23'),
	(126,'BANGLADESH','BD','BGD','Bangladesh',50,0,'2014-05-08 16:06:23'),
	(127,'COMOROS','KM','COM','Comoros',174,1,'2014-05-08 16:06:23'),
	(128,'FRENCH POLYNESIA','PF','PYF','French Polynesia',258,0,'2014-05-08 16:06:23'),
	(129,'MALI','ML','MLI','Mali',466,0,'2014-05-08 16:06:23'),
	(130,'NORFOLK ISLAND','NF','NFK','Norfolk Island',574,0,'2014-05-08 16:06:23'),
	(131,'TUNISIA','TN','TUN','Tunisia',788,0,'2014-05-08 16:06:23'),
	(132,'BARBADOS','BB','BRB','Barbados',52,0,'2014-05-08 16:06:23'),
	(133,'CONGO','CG','COG','Congo',178,0,'2014-05-08 16:06:23'),
	(134,'GABON','GA','GAB','Gabon',266,0,'2014-05-08 16:06:23'),
	(135,'MALTA','MT','MLT','Malta',470,0,'2014-05-08 16:06:23'),
	(136,'NORTHERN MARIANA ISLANDS','MP','MNP','Northern Mariana Islands',580,0,'2014-05-08 16:06:23'),
	(137,'TURKEY','TR','TUR','Turkey',792,0,'2014-05-08 16:06:23'),
	(138,'CONGO, THE DEMOCRATIC REPUBLIC OF THE','CD','COD','Congo, the Democratic Republic of the',180,0,'2014-05-08 16:06:23'),
	(139,'MARSHALL ISLANDS','MH','MHL','Marshall Islands',584,0,'2014-05-08 16:06:23'),
	(140,'NORWAY','NO','NOR','Norway',578,0,'2014-05-08 16:06:23'),
	(141,'TURKMENISTAN','TM','TKM','Turkmenistan',795,0,'2014-05-08 16:06:23'),
	(142,'BELARUS','BY','BLR','Belarus',112,0,'2014-05-08 16:06:23'),
	(143,'COOK ISLANDS','CK','COK','Cook Islands',184,0,'2014-05-08 16:06:23'),
	(144,'GAMBIA','GM','GMB','Gambia',270,0,'2014-05-08 16:06:23'),
	(145,'MARTINIQUE','MQ','MTQ','Martinique',474,0,'2014-05-08 16:06:23'),
	(146,'OMAN','OM','OMN','Oman',512,0,'2014-05-08 16:06:23'),
	(147,'SEYCHELLES','SC','SYC','Seychelles',690,0,'2014-05-08 16:06:23'),
	(148,'TURKS AND CAICOS ISLANDS','TC','TCA','Turks and Caicos Islands',796,0,'2014-05-08 16:06:23'),
	(149,'GEORGIA','GE','GEO','Georgia',268,0,'2014-05-08 16:06:23'),
	(150,'MAURITANIA','MR','MRT','Mauritania',478,0,'2014-05-08 16:06:23'),
	(151,'PAKISTAN','PK','PAK','Pakistan',586,1,'2014-05-08 16:06:23'),
	(152,'SIERRA LEONE','SL','SLE','Sierra Leone',694,0,'2014-05-08 16:06:23'),
	(153,'TUVALU','TV','TUV','Tuvalu',798,0,'2014-05-08 16:06:23'),
	(154,'COSTA RICA','CR','CRI','Costa Rica',188,0,'2014-05-08 16:06:23'),
	(155,'GERMANY','DE','DEU','Germany',276,0,'2014-05-08 16:06:23'),
	(156,'MAURITIUS','MU','MUS','Mauritius',480,0,'2014-05-08 16:06:23'),
	(157,'PALAU','PW','PLW','Palau',585,0,'2014-05-08 16:06:23'),
	(158,'COTE D\'IVOIRE','CI','CIV','Cote D\'Ivoire',384,0,'2014-05-08 16:06:23'),
	(159,'PANAMA','PA','PAN','Panama',591,0,'2014-05-08 16:06:23'),
	(160,'SINGAPORE','SG','SGP','Singapore',702,0,'2014-05-08 16:06:23'),
	(161,'CROATIA','HR','HRV','Croatia',191,0,'2014-05-08 16:06:23'),
	(162,'GHANA','GH','GHA','Ghana',288,0,'2014-05-08 16:06:23'),
	(163,'PAPUA NEW GUINEA','PG','PNG','Papua New Guinea',598,0,'2014-05-08 16:06:23'),
	(164,'SLOVAKIA','SK','SVK','Slovakia',703,0,'2014-05-08 16:06:23'),
	(165,'GIBRALTAR','GI','GIB','Gibraltar',292,0,'2014-05-08 16:06:23'),
	(166,'PARAGUAY','PY','PRY','Paraguay',600,0,'2014-05-08 16:06:23'),
	(167,'SLOVENIA','SI','SVN','Slovenia',705,0,'2014-05-08 16:06:23'),
	(168,'GREECE','GR','GRC','Greece',300,0,'2014-05-08 16:06:23'),
	(169,'PERU','PE','PER','Peru',604,0,'2014-05-08 16:06:23'),
	(170,'SOLOMON ISLANDS','SB','SLB','Solomon Islands',90,0,'2014-05-08 16:06:23'),
	(171,'GREENLAND','GL','GRL','Greenland',304,0,'2014-05-08 16:06:23'),
	(172,'SOMALIA','SO','SOM','Somalia',706,1,'2014-05-08 16:06:23'),
	(173,'GRENADA','GD','GRD','Grenada',308,0,'2014-05-08 16:06:23'),
	(174,'SOUTH AFRICA','ZA','ZAF','South Africa',710,0,'2014-05-08 16:06:23'),
	(175,'SPAIN','ES','ESP','Spain',724,0,'2014-05-08 16:06:23'),
	(176,'SRI LANKA','LK','LKA','Sri Lanka',144,0,'2014-05-08 16:06:23'),
	(177,'AFGHANISTAN','AF','AFG','Afghanistan',4,0,'2014-05-08 16:06:23'),
	(178,'ALBANIA','AL','ALB','Albania',8,0,'2014-05-08 16:06:23'),
	(179,'ALGERIA','DZ','DZA','Algeria',12,0,'2014-05-08 16:06:23'),
	(180,'LATVIA','LV','LVA','Latvia',428,0,'2014-05-08 16:06:23'),
	(181,'AMERICAN SAMOA','AS','ASM','American Samoa',16,0,'2014-05-08 16:06:23'),
	(182,'BULGARIA','BG','BGR','Bulgaria',100,0,'2014-05-08 16:06:23'),
	(183,'LEBANON','LB','LBN','Lebanon',422,0,'2014-05-08 16:06:23'),
	(184,'ANDORRA','AD','AND','Andorra',20,0,'2014-05-08 16:06:23'),
	(185,'BURKINA FASO','BF','BFA','Burkina Faso',854,0,'2014-05-08 16:06:23'),
	(186,'LESOTHO','LS','LSO','Lesotho',426,0,'2014-05-08 16:06:23'),
	(187,'ANGOLA','AO','AGO','Angola',24,0,'2014-05-08 16:06:23'),
	(188,'BURUNDI','BI','BDI','Burundi',108,0,'2014-05-08 16:06:23'),
	(189,'LIBERIA','LR','LBR','Liberia',430,0,'2014-05-08 16:06:23'),
	(190,'VIRGIN ISLANDS, BRITISH','VG','VGB','Virgin Islands, British',92,0,'2014-05-08 16:06:23'),
	(191,'ANGUILLA','AI','AIA','Anguilla',660,0,'2014-05-08 16:06:23'),
	(192,'CAMBODIA','KH','KHM','Cambodia',116,0,'2014-05-08 16:06:23'),
	(193,'EQUATORIAL GUINEA','GQ','GNQ','Equatorial Guinea',226,0,'2014-05-08 16:06:23'),
	(194,'LIBYAN ARAB JAMAHIRIYA','LY','LBY','Libyan Arab Jamahiriya',434,0,'2014-05-08 16:06:23'),
	(195,'NAURU','NR','NRU','Nauru',520,0,'2014-05-08 16:06:23'),
	(196,'VIRGIN ISLANDS, U.S.','VI','VIR','Virgin Islands, U.S.',850,0,'2014-05-08 16:06:23'),
	(197,'ANTIGUA AND BARBUDA','AG','ATG','Antigua and Barbuda',28,0,'2014-05-08 16:06:23'),
	(198,'CAMEROON','CM','CMR','Cameroon',120,0,'2014-05-08 16:06:23'),
	(199,'LIECHTENSTEIN','LI','LIE','Liechtenstein',438,0,'2014-05-08 16:06:23'),
	(200,'NEPAL','NP','NPL','Nepal',524,1,'2014-05-08 16:06:23'),
	(201,'WALLIS AND FUTUNA','WF','WLF','Wallis and Futuna',876,0,'2014-05-08 16:06:23'),
	(202,'WESTERN SAHARA','EH','ESH','Western Sahara',732,0,'2014-05-08 16:06:23'),
	(203,'ARGENTINA','AR','ARG','Argentina',32,0,'2014-05-08 16:06:23'),
	(204,'CANADA','CA','CAN','Canada',124,1,'2014-05-08 16:06:23'),
	(205,'ERITREA','ER','ERI','Eritrea',232,0,'2014-05-08 16:06:23'),
	(206,'LITHUANIA','LT','LTU','Lithuania',440,0,'2014-05-08 16:06:23'),
	(207,'NETHERLANDS','NL','NLD','Netherlands',528,0,'2014-05-08 16:06:23'),
	(208,'YEMEN','YE','YEM','Yemen',887,0,'2014-05-08 16:06:23'),
	(209,'CAPE VERDE','CV','CPV','Cape Verde',132,0,'2014-05-08 16:06:23'),
	(210,'ESTONIA','EE','EST','Estonia',233,0,'2014-05-08 16:06:23'),
	(211,'LUXEMBOURG','LU','LUX','Luxembourg',442,0,'2014-05-08 16:06:23'),
	(212,'NETHERLANDS ANTILLES','AN','ANT','Netherlands Antilles',530,0,'2014-05-08 16:06:23'),
	(213,'SAINT HELENA','SH','SHN','Saint Helena',654,0,'2014-05-08 16:06:23'),
	(214,'ZAMBIA','ZM','ZMB','Zambia',894,0,'2014-05-08 16:06:23'),
	(215,'CAYMAN ISLANDS','KY','CYM','Cayman Islands',136,0,'2014-05-08 16:06:23'),
	(216,'ETHIOPIA','ET','ETH','Ethiopia',231,1,'2014-05-08 16:06:23'),
	(217,'HUNGARY','HU','HUN','Hungary',348,0,'2014-05-08 16:06:23'),
	(218,'MACAO','MO','MAC','Macao',446,0,'2014-05-08 16:06:23'),
	(219,'NEW CALEDONIA','NC','NCL','New Caledonia',540,0,'2014-05-08 16:06:23'),
	(220,'ZIMBABWE','ZW','ZWE','Zimbabwe',716,0,'2014-05-08 16:06:23'),
	(221,'CENTRAL AFRICAN REPUBLIC','CF','CAF','Central African Republic',140,0,'2014-05-08 16:06:23'),
	(222,'FALKLAND ISLANDS (MALVINAS)','FK','FLK','Falkland Islands (Malvinas)',238,0,'2014-05-08 16:06:23'),
	(223,'ICELAND','IS','ISL','Iceland',352,0,'2014-05-08 16:06:23'),
	(224,'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF','MK','MKD','Macedonia',807,0,'2014-05-08 16:06:23'),
	(225,'NEW ZEALAND','NZ','NZL','New Zealand',554,0,'2014-05-08 16:06:23'),
	(226,'SAINT KITTS AND NEVIS','KN','KNA','Saint Kitts and Nevis',659,1,'2014-05-08 16:06:23'),
	(227,'SERBIA','RS','SRB','Serbia',999,0,'2014-05-08 16:06:23'),
	(228,'MONTENEGRO','ME','MNE','Montenegro',499,0,'2014-05-08 16:06:23');

/*!40000 ALTER TABLE `spree_countries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_credit_cards
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_credit_cards`;

CREATE TABLE `spree_credit_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `cc_type` varchar(255) DEFAULT NULL,
  `last_digits` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `gateway_customer_profile_id` varchar(255) DEFAULT NULL,
  `gateway_payment_profile_id` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_credit_cards_on_user_id` (`user_id`),
  KEY `index_spree_credit_cards_on_payment_method_id` (`payment_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_gateways
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_gateways`;

CREATE TABLE `spree_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `active` tinyint(1) DEFAULT '1',
  `environment` varchar(255) DEFAULT 'development',
  `server` varchar(255) DEFAULT 'test',
  `test_mode` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_inventory_units
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_inventory_units`;

CREATE TABLE `spree_inventory_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `shipment_id` int(11) DEFAULT NULL,
  `return_authorization_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `pending` tinyint(1) DEFAULT '1',
  `line_item_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_inventory_units_on_order_id` (`order_id`),
  KEY `index_inventory_units_on_shipment_id` (`shipment_id`),
  KEY `index_inventory_units_on_variant_id` (`variant_id`),
  KEY `index_spree_inventory_units_on_line_item_id` (`line_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_inventory_units` WRITE;
/*!40000 ALTER TABLE `spree_inventory_units` DISABLE KEYS */;

INSERT INTO `spree_inventory_units` (`id`, `state`, `variant_id`, `order_id`, `shipment_id`, `return_authorization_id`, `created_at`, `updated_at`, `pending`, `line_item_id`)
VALUES
	(1,'on_hand',1,3,1,NULL,'2014-05-08 15:08:46','2014-05-08 15:08:46',1,1),
	(2,'on_hand',1,3,1,NULL,'2014-05-08 15:08:46','2014-05-08 15:08:46',1,1);

/*!40000 ALTER TABLE `spree_inventory_units` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_line_items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_line_items`;

CREATE TABLE `spree_line_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `variant_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `cost_price` decimal(8,2) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `adjustment_total` decimal(10,2) DEFAULT '0.00',
  `additional_tax_total` decimal(10,2) DEFAULT '0.00',
  `promo_total` decimal(10,2) DEFAULT '0.00',
  `included_tax_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pre_tax_amount` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_line_items_on_order_id` (`order_id`),
  KEY `index_spree_line_items_on_variant_id` (`variant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_line_items` WRITE;
/*!40000 ALTER TABLE `spree_line_items` DISABLE KEYS */;

INSERT INTO `spree_line_items` (`id`, `variant_id`, `order_id`, `quantity`, `price`, `created_at`, `updated_at`, `currency`, `cost_price`, `tax_category_id`, `adjustment_total`, `additional_tax_total`, `promo_total`, `included_tax_total`, `pre_tax_amount`)
VALUES
	(1,1,3,2,50.00,'2014-05-08 15:08:46','2014-05-08 15:08:46','MYR',10.00,NULL,0.00,0.00,0.00,0.00,NULL);

/*!40000 ALTER TABLE `spree_line_items` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_log_entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_log_entries`;

CREATE TABLE `spree_log_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_id` int(11) DEFAULT NULL,
  `source_type` varchar(255) DEFAULT NULL,
  `details` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_option_types
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_option_types`;

CREATE TABLE `spree_option_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `presentation` varchar(100) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_option_types_prototypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_option_types_prototypes`;

CREATE TABLE `spree_option_types_prototypes` (
  `prototype_id` int(11) DEFAULT NULL,
  `option_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_option_values
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_option_values`;

CREATE TABLE `spree_option_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `presentation` varchar(255) DEFAULT NULL,
  `option_type_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_option_values_on_option_type_id` (`option_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_option_values_variants
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_option_values_variants`;

CREATE TABLE `spree_option_values_variants` (
  `variant_id` int(11) DEFAULT NULL,
  `option_value_id` int(11) DEFAULT NULL,
  KEY `index_option_values_variants_on_variant_id_and_option_value_id` (`variant_id`,`option_value_id`),
  KEY `index_spree_option_values_variants_on_variant_id` (`variant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_orders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_orders`;

CREATE TABLE `spree_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(32) DEFAULT NULL,
  `item_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `state` varchar(255) DEFAULT NULL,
  `adjustment_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `user_id` int(11) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `bill_address_id` int(11) DEFAULT NULL,
  `ship_address_id` int(11) DEFAULT NULL,
  `payment_total` decimal(10,2) DEFAULT '0.00',
  `shipping_method_id` int(11) DEFAULT NULL,
  `shipment_state` varchar(255) DEFAULT NULL,
  `payment_state` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `special_instructions` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `last_ip_address` varchar(255) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  `shipment_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `additional_tax_total` decimal(10,2) DEFAULT '0.00',
  `promo_total` decimal(10,2) DEFAULT '0.00',
  `channel` varchar(255) DEFAULT 'spree',
  `included_tax_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_count` int(11) DEFAULT '0',
  `approver_id` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `confirmation_delivered` tinyint(1) DEFAULT '0',
  `considered_risky` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_spree_orders_on_number` (`number`),
  KEY `index_spree_orders_on_user_id` (`user_id`),
  KEY `index_spree_orders_on_completed_at` (`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_orders` WRITE;
/*!40000 ALTER TABLE `spree_orders` DISABLE KEYS */;

INSERT INTO `spree_orders` (`id`, `number`, `item_total`, `total`, `state`, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`, `payment_total`, `shipping_method_id`, `shipment_state`, `payment_state`, `email`, `special_instructions`, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`)
VALUES
	(1,'R680012150',0.00,0.00,'cart',0.00,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,'2014-05-08 15:06:50','2014-05-08 15:06:50','MYR',NULL,3,0.00,0.00,0.00,'spree',0.00,0,NULL,NULL,0,0),
	(2,'R474260200',0.00,0.00,'cart',0.00,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,'2014-05-08 15:07:11','2014-05-08 15:07:11','MYR',NULL,3,0.00,0.00,0.00,'spree',0.00,0,NULL,NULL,0,0),
	(3,'R583211117',100.00,100.00,'address',0.00,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,'2014-05-08 15:08:25','2014-05-08 15:08:47','MYR',NULL,3,0.00,0.00,0.00,'spree',0.00,2,NULL,NULL,0,0);

/*!40000 ALTER TABLE `spree_orders` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_orders_promotions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_orders_promotions`;

CREATE TABLE `spree_orders_promotions` (
  `order_id` int(11) DEFAULT NULL,
  `promotion_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_pages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_pages`;

CREATE TABLE `spree_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `body` text,
  `slug` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `show_in_header` tinyint(1) NOT NULL DEFAULT '0',
  `show_in_footer` tinyint(1) NOT NULL DEFAULT '0',
  `foreign_link` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT '1',
  `visible` tinyint(1) DEFAULT '1',
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `layout` varchar(255) DEFAULT NULL,
  `show_in_sidebar` tinyint(1) NOT NULL DEFAULT '0',
  `meta_title` varchar(255) DEFAULT NULL,
  `render_layout_as_partial` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_spree_pages_on_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_payment_capture_events
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_payment_capture_events`;

CREATE TABLE `spree_payment_capture_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) DEFAULT '0.00',
  `payment_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_payment_capture_events_on_payment_id` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_payment_methods
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_payment_methods`;

CREATE TABLE `spree_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `active` tinyint(1) DEFAULT '1',
  `environment` varchar(255) DEFAULT 'development',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `display_on` varchar(255) DEFAULT NULL,
  `auto_capture` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_payment_methods_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_payment_methods` WRITE;
/*!40000 ALTER TABLE `spree_payment_methods` DISABLE KEYS */;

INSERT INTO `spree_payment_methods` (`id`, `type`, `name`, `description`, `active`, `environment`, `deleted_at`, `created_at`, `updated_at`, `display_on`, `auto_capture`)
VALUES
	(1,'Spree::Gateway::Banwire','Online Bank','',1,'james',NULL,'2014-05-08 15:10:18','2014-05-08 15:10:18','',NULL),
	(2,'Spree::Gateway::Banwire','Online Bank 2','',1,'james','2014-05-08 16:19:03','2014-05-08 15:11:50','2014-05-08 16:19:03','',NULL);

/*!40000 ALTER TABLE `spree_payment_methods` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_payments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_payments`;

CREATE TABLE `spree_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `order_id` int(11) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `source_type` varchar(255) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `response_code` varchar(255) DEFAULT NULL,
  `avs_response` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `cvv_response_code` varchar(255) DEFAULT NULL,
  `cvv_response_message` varchar(255) DEFAULT NULL,
  `uncaptured_amount` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `index_spree_payments_on_order_id` (`order_id`),
  KEY `index_spree_payments_on_payment_method_id` (`payment_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_preferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_preferences`;

CREATE TABLE `spree_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text,
  `key` varchar(255) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_spree_preferences_on_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_preferences` WRITE;
/*!40000 ALTER TABLE `spree_preferences` DISABLE KEYS */;

INSERT INTO `spree_preferences` (`id`, `value`, `key`, `value_type`, `created_at`, `updated_at`)
VALUES
	(1,'--- logo/wifi_logo.png\n...\n','spree/app_configuration/logo','string','2014-04-28 15:17:50','2014-05-08 16:13:12'),
	(2,'--- logo/wifi_logo.png\n...\n','spree/app_configuration/admin_interface_logo','string','2014-04-28 15:17:50','2014-05-08 16:13:12'),
	(3,'--- AJI-NO-RIKI\n...\n','spree/app_configuration/site_name','string','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(4,'--- AJI-NO-RIKI\n...\n','spree/app_configuration/default_seo_title','string','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(5,'--- \'AJI-NO-RIKI, flavour, \'\n','spree/app_configuration/default_meta_keywords','string','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(6,'--- AJI-NO-RIKI flavour enhancer, msg, monosodium glutamate\n...\n','spree/app_configuration/default_meta_description','string','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(7,'--- http://aji-no-riki.com.my/\n...\n','spree/app_configuration/site_url','string','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(8,'--- true\n...\n','spree/app_configuration/allow_ssl_in_production','boolean','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(9,'--- true\n...\n','spree/app_configuration/allow_ssl_in_staging','boolean','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(10,'--- false\n...\n','spree/app_configuration/allow_ssl_in_development_and_test','boolean','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(11,'--- true\n...\n','spree/app_configuration/check_for_spree_alerts','boolean','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(12,'--- false\n...\n','spree/app_configuration/display_currency','boolean','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(13,'--- false\n...\n','spree/app_configuration/hide_cents','boolean','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(14,'--- MYR\n...\n','spree/app_configuration/currency','string','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(15,'--- before\n...\n','spree/app_configuration/currency_symbol_position','string','2014-05-02 05:40:51','2014-05-02 05:40:51'),
	(16,'--- .\n...\n','spree/app_configuration/currency_decimal_mark','string','2014-05-02 05:40:52','2014-05-02 05:40:52'),
	(17,'--- \',\'\n','spree/app_configuration/currency_thousands_separator','string','2014-05-02 05:40:52','2014-05-02 05:40:52'),
	(18,'--- 120\n...\n','spree/app_configuration/default_country_id','integer','2014-05-08 16:00:42','2014-05-08 16:06:24');

/*!40000 ALTER TABLE `spree_preferences` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_prices
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_prices`;

CREATE TABLE `spree_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `variant_id` int(11) NOT NULL,
  `amount` decimal(8,2) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_prices_on_variant_id_and_currency` (`variant_id`,`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_prices` WRITE;
/*!40000 ALTER TABLE `spree_prices` DISABLE KEYS */;

INSERT INTO `spree_prices` (`id`, `variant_id`, `amount`, `currency`, `deleted_at`)
VALUES
	(1,1,100.00,'USD',NULL),
	(2,1,50.00,'MYR',NULL);

/*!40000 ALTER TABLE `spree_prices` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_product_option_types
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_product_option_types`;

CREATE TABLE `spree_product_option_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `option_type_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_product_properties
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_product_properties`;

CREATE TABLE `spree_product_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_product_properties_on_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_products
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_products`;

CREATE TABLE `spree_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `available_on` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `meta_description` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `shipping_category_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permalink_idx_unique` (`slug`),
  KEY `index_spree_products_on_available_on` (`available_on`),
  KEY `index_spree_products_on_deleted_at` (`deleted_at`),
  KEY `index_spree_products_on_name` (`name`),
  KEY `index_spree_products_on_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_products` WRITE;
/*!40000 ALTER TABLE `spree_products` DISABLE KEYS */;

INSERT INTO `spree_products` (`id`, `name`, `description`, `available_on`, `deleted_at`, `slug`, `meta_description`, `meta_keywords`, `tax_category_id`, `shipping_category_id`, `created_at`, `updated_at`)
VALUES
	(1,'abc','','2014-04-28 00:00:00',NULL,'abc','','',NULL,1,'2014-04-28 15:28:01','2014-05-08 15:08:13');

/*!40000 ALTER TABLE `spree_products` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_products_promotion_rules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_products_promotion_rules`;

CREATE TABLE `spree_products_promotion_rules` (
  `product_id` int(11) DEFAULT NULL,
  `promotion_rule_id` int(11) DEFAULT NULL,
  KEY `index_products_promotion_rules_on_product_id` (`product_id`),
  KEY `index_products_promotion_rules_on_promotion_rule_id` (`promotion_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_products_taxons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_products_taxons`;

CREATE TABLE `spree_products_taxons` (
  `product_id` int(11) DEFAULT NULL,
  `taxon_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_products_taxons_on_product_id` (`product_id`),
  KEY `index_spree_products_taxons_on_taxon_id` (`taxon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_promotion_action_line_items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_promotion_action_line_items`;

CREATE TABLE `spree_promotion_action_line_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_action_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_promotion_actions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_promotion_actions`;

CREATE TABLE `spree_promotion_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_promotion_actions_on_id_and_type` (`id`,`type`),
  KEY `index_spree_promotion_actions_on_promotion_id` (`promotion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_promotion_rules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_promotion_rules`;

CREATE TABLE `spree_promotion_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_group_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_promotion_rules_on_product_group_id` (`product_group_id`),
  KEY `index_promotion_rules_on_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_promotion_rules_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_promotion_rules_users`;

CREATE TABLE `spree_promotion_rules_users` (
  `user_id` int(11) DEFAULT NULL,
  `promotion_rule_id` int(11) DEFAULT NULL,
  KEY `index_promotion_rules_users_on_promotion_rule_id` (`promotion_rule_id`),
  KEY `index_promotion_rules_users_on_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_promotions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_promotions`;

CREATE TABLE `spree_promotions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `starts_at` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `match_policy` varchar(255) DEFAULT 'all',
  `code` varchar(255) DEFAULT NULL,
  `advertise` tinyint(1) DEFAULT '0',
  `path` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_promotions_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_properties
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_properties`;

CREATE TABLE `spree_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `presentation` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_properties_prototypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_properties_prototypes`;

CREATE TABLE `spree_properties_prototypes` (
  `prototype_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_prototypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_prototypes`;

CREATE TABLE `spree_prototypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_return_authorizations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_return_authorizations`;

CREATE TABLE `spree_return_authorizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `order_id` int(11) DEFAULT NULL,
  `reason` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `stock_location_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_roles`;

CREATE TABLE `spree_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_roles` WRITE;
/*!40000 ALTER TABLE `spree_roles` DISABLE KEYS */;

INSERT INTO `spree_roles` (`id`, `name`)
VALUES
	(1,'admin'),
	(2,'user');

/*!40000 ALTER TABLE `spree_roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_roles_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_roles_users`;

CREATE TABLE `spree_roles_users` (
  `role_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  KEY `index_spree_roles_users_on_role_id` (`role_id`),
  KEY `index_spree_roles_users_on_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_roles_users` WRITE;
/*!40000 ALTER TABLE `spree_roles_users` DISABLE KEYS */;

INSERT INTO `spree_roles_users` (`role_id`, `user_id`)
VALUES
	(1,1),
	(1,2),
	(1,3);

/*!40000 ALTER TABLE `spree_roles_users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_shipments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_shipments`;

CREATE TABLE `spree_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracking` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `cost` decimal(8,2) DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `stock_location_id` int(11) DEFAULT NULL,
  `adjustment_total` decimal(10,2) DEFAULT '0.00',
  `additional_tax_total` decimal(10,2) DEFAULT '0.00',
  `promo_total` decimal(10,2) DEFAULT '0.00',
  `included_tax_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pre_tax_amount` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_shipments_on_number` (`number`),
  KEY `index_spree_shipments_on_order_id` (`order_id`),
  KEY `index_spree_shipments_on_stock_location_id` (`stock_location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_shipments` WRITE;
/*!40000 ALTER TABLE `spree_shipments` DISABLE KEYS */;

INSERT INTO `spree_shipments` (`id`, `tracking`, `number`, `cost`, `shipped_at`, `order_id`, `address_id`, `state`, `created_at`, `updated_at`, `stock_location_id`, `adjustment_total`, `additional_tax_total`, `promo_total`, `included_tax_total`, `pre_tax_amount`)
VALUES
	(1,NULL,'H41556306576',0.00,NULL,3,NULL,'pending','2014-05-08 15:08:45','2014-05-08 15:08:46',1,0.00,0.00,0.00,0.00,NULL);

/*!40000 ALTER TABLE `spree_shipments` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_shipping_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_shipping_categories`;

CREATE TABLE `spree_shipping_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_shipping_categories` WRITE;
/*!40000 ALTER TABLE `spree_shipping_categories` DISABLE KEYS */;

INSERT INTO `spree_shipping_categories` (`id`, `name`, `created_at`, `updated_at`)
VALUES
	(1,'Default','2014-04-28 15:16:52','2014-04-28 15:16:52');

/*!40000 ALTER TABLE `spree_shipping_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_shipping_method_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_shipping_method_categories`;

CREATE TABLE `spree_shipping_method_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shipping_method_id` int(11) NOT NULL,
  `shipping_category_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_spree_shipping_method_categories` (`shipping_category_id`,`shipping_method_id`),
  KEY `index_spree_shipping_method_categories_on_shipping_method_id` (`shipping_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_shipping_methods
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_shipping_methods`;

CREATE TABLE `spree_shipping_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `display_on` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `tracking_url` varchar(255) DEFAULT NULL,
  `admin_name` varchar(255) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_shipping_methods_zones
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_shipping_methods_zones`;

CREATE TABLE `spree_shipping_methods_zones` (
  `shipping_method_id` int(11) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_shipping_rates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_shipping_rates`;

CREATE TABLE `spree_shipping_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shipment_id` int(11) DEFAULT NULL,
  `shipping_method_id` int(11) DEFAULT NULL,
  `selected` tinyint(1) DEFAULT '0',
  `cost` decimal(8,2) DEFAULT '0.00',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `spree_shipping_rates_join_index` (`shipment_id`,`shipping_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_skrill_transactions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_skrill_transactions`;

CREATE TABLE `spree_skrill_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_state_changes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_state_changes`;

CREATE TABLE `spree_state_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `previous_state` varchar(255) DEFAULT NULL,
  `stateful_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `stateful_type` varchar(255) DEFAULT NULL,
  `next_state` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_state_changes` WRITE;
/*!40000 ALTER TABLE `spree_state_changes` DISABLE KEYS */;

INSERT INTO `spree_state_changes` (`id`, `name`, `previous_state`, `stateful_id`, `user_id`, `stateful_type`, `next_state`, `created_at`, `updated_at`)
VALUES
	(1,'order','cart',3,NULL,'Spree::Order','address','2014-05-08 15:08:46','2014-05-08 15:08:46');

/*!40000 ALTER TABLE `spree_state_changes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_states
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_states`;

CREATE TABLE `spree_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `abbr` varchar(255) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_states` WRITE;
/*!40000 ALTER TABLE `spree_states` DISABLE KEYS */;

INSERT INTO `spree_states` (`id`, `name`, `abbr`, `country_id`, `updated_at`)
VALUES
	(1,'Michigan','MI',49,'2014-05-08 16:06:23'),
	(2,'South Dakota','SD',49,'2014-05-08 16:06:23'),
	(3,'Washington','WA',49,'2014-05-08 16:06:24'),
	(4,'Wisconsin','WI',49,'2014-05-08 16:06:24'),
	(5,'Arizona','AZ',49,'2014-05-08 16:06:24'),
	(6,'Illinois','IL',49,'2014-05-08 16:06:24'),
	(7,'New Hampshire','NH',49,'2014-05-08 16:06:24'),
	(8,'North Carolina','NC',49,'2014-05-08 16:06:24'),
	(9,'Kansas','KS',49,'2014-05-08 16:06:24'),
	(10,'Missouri','MO',49,'2014-05-08 16:06:24'),
	(11,'Arkansas','AR',49,'2014-05-08 16:06:24'),
	(12,'Nevada','NV',49,'2014-05-08 16:06:24'),
	(13,'District of Columbia','DC',49,'2014-05-08 16:06:24'),
	(14,'Idaho','ID',49,'2014-05-08 16:06:24'),
	(15,'Nebraska','NE',49,'2014-05-08 16:06:24'),
	(16,'Pennsylvania','PA',49,'2014-05-08 16:06:24'),
	(17,'Hawaii','HI',49,'2014-05-08 16:06:24'),
	(18,'Utah','UT',49,'2014-05-08 16:06:24'),
	(19,'Vermont','VT',49,'2014-05-08 16:06:24'),
	(20,'Delaware','DE',49,'2014-05-08 16:06:24'),
	(21,'Rhode Island','RI',49,'2014-05-08 16:06:24'),
	(22,'Oklahoma','OK',49,'2014-05-08 16:06:24'),
	(23,'Louisiana','LA',49,'2014-05-08 16:06:24'),
	(24,'Montana','MT',49,'2014-05-08 16:06:24'),
	(25,'Tennessee','TN',49,'2014-05-08 16:06:24'),
	(26,'Maryland','MD',49,'2014-05-08 16:06:24'),
	(27,'Florida','FL',49,'2014-05-08 16:06:24'),
	(28,'Virginia','VA',49,'2014-05-08 16:06:24'),
	(29,'Minnesota','MN',49,'2014-05-08 16:06:24'),
	(30,'New Jersey','NJ',49,'2014-05-08 16:06:24'),
	(31,'Ohio','OH',49,'2014-05-08 16:06:24'),
	(32,'California','CA',49,'2014-05-08 16:06:24'),
	(33,'North Dakota','ND',49,'2014-05-08 16:06:24'),
	(34,'Maine','ME',49,'2014-05-08 16:06:24'),
	(35,'Indiana','IN',49,'2014-05-08 16:06:24'),
	(36,'Texas','TX',49,'2014-05-08 16:06:24'),
	(37,'Oregon','OR',49,'2014-05-08 16:06:24'),
	(38,'Wyoming','WY',49,'2014-05-08 16:06:24'),
	(39,'Alabama','AL',49,'2014-05-08 16:06:24'),
	(40,'Iowa','IA',49,'2014-05-08 16:06:24'),
	(41,'Mississippi','MS',49,'2014-05-08 16:06:24'),
	(42,'Kentucky','KY',49,'2014-05-08 16:06:24'),
	(43,'New Mexico','NM',49,'2014-05-08 16:06:24'),
	(44,'Georgia','GA',49,'2014-05-08 16:06:24'),
	(45,'Colorado','CO',49,'2014-05-08 16:06:24'),
	(46,'Massachusetts','MA',49,'2014-05-08 16:06:24'),
	(47,'Connecticut','CT',49,'2014-05-08 16:06:24'),
	(48,'New York','NY',49,'2014-05-08 16:06:24'),
	(49,'South Carolina','SC',49,'2014-05-08 16:06:24'),
	(50,'Alaska','AK',49,'2014-05-08 16:06:24'),
	(51,'West Virginia','WV',49,'2014-05-08 16:06:24'),
	(52,'U.S. Armed Forces - Americas','AA',49,'2014-05-08 16:06:24'),
	(53,'U.S. Armed Forces - Europe','AE',49,'2014-05-08 16:06:24'),
	(54,'U.S. Armed Forces - Pacific','AP',49,'2014-05-08 16:06:24'),
	(55,'Federal Territory of Kuala Lumpur','KUL',120,'2014-05-08 16:06:25'),
	(56,'Federal Territory of Labuan','LBN',120,'2014-05-08 16:06:25'),
	(57,'Federal Territory of Putrajaya','PJY',120,'2014-05-08 16:06:25'),
	(58,'Johor','JHR',120,'2014-05-08 16:06:25'),
	(59,'Kedah','KDH',120,'2014-05-08 16:06:25'),
	(60,'Kelantan','KTN',120,'2014-05-08 16:06:25'),
	(61,'Malacca','MLK',120,'2014-05-08 16:06:25'),
	(62,'Negeri Sembilan','NSN',120,'2014-05-08 16:06:25'),
	(63,'Pahang','PHG',120,'2014-05-08 16:06:25'),
	(64,'Perak','PRK',120,'2014-05-08 16:06:25'),
	(65,'Perlis','PLS',120,'2014-05-08 16:06:25'),
	(66,'Penang','PNG',120,'2014-05-08 16:06:25'),
	(67,'Sabah','SBH',120,'2014-05-08 16:06:25'),
	(68,'Sarawak','SWK',120,'2014-05-08 16:06:25'),
	(69,'Selangor','SGR',120,'2014-05-08 16:06:25'),
	(70,'Terengganu','TRG',120,'2014-05-08 16:06:25');

/*!40000 ALTER TABLE `spree_states` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_stock_items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_stock_items`;

CREATE TABLE `spree_stock_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_location_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `count_on_hand` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `backorderable` tinyint(1) DEFAULT '0',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_stock_items_on_stock_location_id` (`stock_location_id`),
  KEY `stock_item_by_loc_and_var_id` (`stock_location_id`,`variant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_stock_items` WRITE;
/*!40000 ALTER TABLE `spree_stock_items` DISABLE KEYS */;

INSERT INTO `spree_stock_items` (`id`, `stock_location_id`, `variant_id`, `count_on_hand`, `created_at`, `updated_at`, `backorderable`, `deleted_at`)
VALUES
	(1,1,1,100,'2014-04-28 15:28:01','2014-05-08 15:08:13',1,NULL);

/*!40000 ALTER TABLE `spree_stock_items` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_stock_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_stock_locations`;

CREATE TABLE `spree_stock_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `state_name` varchar(255) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `backorderable_default` tinyint(1) DEFAULT '0',
  `propagate_all_variants` tinyint(1) DEFAULT '1',
  `admin_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_stock_locations` WRITE;
/*!40000 ALTER TABLE `spree_stock_locations` DISABLE KEYS */;

INSERT INTO `spree_stock_locations` (`id`, `name`, `created_at`, `updated_at`, `address1`, `address2`, `city`, `state_id`, `state_name`, `country_id`, `zipcode`, `phone`, `active`, `backorderable_default`, `propagate_all_variants`, `admin_name`)
VALUES
	(1,'default','2014-04-28 15:16:49','2014-04-28 15:16:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,NULL);

/*!40000 ALTER TABLE `spree_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_stock_movements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_stock_movements`;

CREATE TABLE `spree_stock_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_item_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT '0',
  `action` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `originator_id` int(11) DEFAULT NULL,
  `originator_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_stock_movements_on_stock_item_id` (`stock_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_stock_movements` WRITE;
/*!40000 ALTER TABLE `spree_stock_movements` DISABLE KEYS */;

INSERT INTO `spree_stock_movements` (`id`, `stock_item_id`, `quantity`, `action`, `created_at`, `updated_at`, `originator_id`, `originator_type`)
VALUES
	(1,1,100,NULL,'2014-05-08 15:08:13','2014-05-08 15:08:13',NULL,NULL);

/*!40000 ALTER TABLE `spree_stock_movements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_stock_transfers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_stock_transfers`;

CREATE TABLE `spree_stock_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `source_location_id` int(11) DEFAULT NULL,
  `destination_location_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_stock_transfers_on_number` (`number`),
  KEY `index_spree_stock_transfers_on_source_location_id` (`source_location_id`),
  KEY `index_spree_stock_transfers_on_destination_location_id` (`destination_location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_tax_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_tax_categories`;

CREATE TABLE `spree_tax_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_tax_categories` WRITE;
/*!40000 ALTER TABLE `spree_tax_categories` DISABLE KEYS */;

INSERT INTO `spree_tax_categories` (`id`, `name`, `description`, `is_default`, `deleted_at`, `created_at`, `updated_at`)
VALUES
	(1,'GST','GST Tax',1,NULL,'2014-05-08 16:10:40','2014-05-08 16:10:40');

/*!40000 ALTER TABLE `spree_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_tax_rates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_tax_rates`;

CREATE TABLE `spree_tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(8,5) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `included_in_price` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `show_rate_in_label` tinyint(1) DEFAULT '1',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_tax_rates` WRITE;
/*!40000 ALTER TABLE `spree_tax_rates` DISABLE KEYS */;

INSERT INTO `spree_tax_rates` (`id`, `amount`, `zone_id`, `tax_category_id`, `included_in_price`, `created_at`, `updated_at`, `name`, `show_rate_in_label`, `deleted_at`)
VALUES
	(1,0.06000,4,1,0,'2014-05-08 16:15:51','2014-05-08 16:15:51','GST 6',1,NULL),
	(2,0.06000,5,1,0,'2014-05-08 16:16:34','2014-05-08 16:16:34','GST 6 west',1,NULL);

/*!40000 ALTER TABLE `spree_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_taxonomies
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_taxonomies`;

CREATE TABLE `spree_taxonomies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_taxonomies` WRITE;
/*!40000 ALTER TABLE `spree_taxonomies` DISABLE KEYS */;

INSERT INTO `spree_taxonomies` (`id`, `name`, `created_at`, `updated_at`, `position`)
VALUES
	(1,'Tags','2014-04-28 15:16:54','2014-04-28 15:16:54',0);

/*!40000 ALTER TABLE `spree_taxonomies` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_taxons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_taxons`;

CREATE TABLE `spree_taxons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `permalink` varchar(255) DEFAULT NULL,
  `taxonomy_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `icon_file_name` varchar(255) DEFAULT NULL,
  `icon_content_type` varchar(255) DEFAULT NULL,
  `icon_file_size` int(11) DEFAULT NULL,
  `icon_updated_at` datetime DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_taxons_on_parent_id` (`parent_id`),
  KEY `index_taxons_on_permalink` (`permalink`),
  KEY `index_taxons_on_taxonomy_id` (`taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_taxons` WRITE;
/*!40000 ALTER TABLE `spree_taxons` DISABLE KEYS */;

INSERT INTO `spree_taxons` (`id`, `parent_id`, `position`, `name`, `permalink`, `taxonomy_id`, `lft`, `rgt`, `icon_file_name`, `icon_content_type`, `icon_file_size`, `icon_updated_at`, `description`, `created_at`, `updated_at`, `meta_title`, `meta_description`, `meta_keywords`, `depth`)
VALUES
	(1,NULL,0,'Tags','tags',1,1,2,NULL,NULL,NULL,NULL,NULL,'2014-04-28 15:16:54','2014-04-28 15:16:54',NULL,NULL,NULL,0),
	(2,NULL,0,'Slider','slider',1,3,4,NULL,NULL,NULL,NULL,NULL,'2014-04-28 15:16:54','2014-04-28 15:16:54',NULL,NULL,NULL,0),
	(3,NULL,0,'Featured','featured',1,5,6,NULL,NULL,NULL,NULL,NULL,'2014-04-28 15:16:54','2014-04-28 15:16:54',NULL,NULL,NULL,0),
	(4,NULL,0,'Latest','latest',1,7,8,NULL,NULL,NULL,NULL,NULL,'2014-04-28 15:16:54','2014-04-28 15:16:54',NULL,NULL,NULL,0);

/*!40000 ALTER TABLE `spree_taxons` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_tokenized_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_tokenized_permissions`;

CREATE TABLE `spree_tokenized_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissable_id` int(11) DEFAULT NULL,
  `permissable_type` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_tokenized_name_and_type` (`permissable_id`,`permissable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_tokenized_permissions` WRITE;
/*!40000 ALTER TABLE `spree_tokenized_permissions` DISABLE KEYS */;

INSERT INTO `spree_tokenized_permissions` (`id`, `permissable_id`, `permissable_type`, `token`, `created_at`, `updated_at`)
VALUES
	(1,1,'Spree::Order','c9d8568df602395f','2014-05-08 15:06:50','2014-05-08 15:06:50'),
	(2,2,'Spree::Order','d776ec1f6f0cbb7f','2014-05-08 15:07:11','2014-05-08 15:07:11'),
	(3,3,'Spree::Order','7a3d0012fb4257bd','2014-05-08 15:08:25','2014-05-08 15:08:25');

/*!40000 ALTER TABLE `spree_tokenized_permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_trackers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_trackers`;

CREATE TABLE `spree_trackers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `environment` varchar(255) DEFAULT NULL,
  `analytics_id` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table spree_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_users`;

CREATE TABLE `spree_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `encrypted_password` varchar(128) DEFAULT NULL,
  `password_salt` varchar(128) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `persistence_token` varchar(255) DEFAULT NULL,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `perishable_token` varchar(255) DEFAULT NULL,
  `sign_in_count` int(11) NOT NULL DEFAULT '0',
  `failed_attempts` int(11) NOT NULL DEFAULT '0',
  `last_request_at` datetime DEFAULT NULL,
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) DEFAULT NULL,
  `last_sign_in_ip` varchar(255) DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `ship_address_id` int(11) DEFAULT NULL,
  `bill_address_id` int(11) DEFAULT NULL,
  `authentication_token` varchar(255) DEFAULT NULL,
  `unlock_token` varchar(255) DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `spree_api_key` varchar(48) DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_idx_unique` (`email`),
  KEY `index_spree_users_on_spree_api_key` (`spree_api_key`),
  KEY `index_spree_users_on_client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_users` WRITE;
/*!40000 ALTER TABLE `spree_users` DISABLE KEYS */;

INSERT INTO `spree_users` (`id`, `encrypted_password`, `password_salt`, `email`, `remember_token`, `persistence_token`, `reset_password_token`, `perishable_token`, `sign_in_count`, `failed_attempts`, `last_request_at`, `current_sign_in_at`, `last_sign_in_at`, `current_sign_in_ip`, `last_sign_in_ip`, `login`, `ship_address_id`, `bill_address_id`, `authentication_token`, `unlock_token`, `locked_at`, `reset_password_sent_at`, `created_at`, `updated_at`, `spree_api_key`, `remember_created_at`, `client_id`)
VALUES
	(1,'a49160fee61e6d81d13658a69a1e87c30e8a5275e1b3123286eb55821f9ebce6b98f1b1ef31a14ca8897930bf8f88c2172c8d88f044d887968ee4b3b073429ff','UeNirhK-3oVeKdDiXmCW','james@mercstudio.com',NULL,NULL,'3554c54adf53c66e2446da4bcd2d5a60d03805916445e450269f85facb05c12b',NULL,1,0,NULL,'2014-04-28 15:27:05','2014-04-28 15:27:05','127.0.0.1','127.0.0.1','james@mercstudio.com',NULL,NULL,NULL,NULL,NULL,'2014-05-02 05:28:32','2014-04-28 15:26:02','2014-05-02 05:33:58','0fd355101a8f823f4853a2f8fe85d5489452c10ee6f4fc64',NULL,NULL),
	(2,'96b11aaf1d6d639d13313ba18d4d4c5a0a3e5794221a71d63bc5b849c118af561d7c065437484b4e0bb6832290945bbc8d27e94fd677068ee743fae018c2a0da','bVgDzzK3Rsi4KGLZYZdY','james2@mercstudio.com',NULL,NULL,NULL,NULL,1,0,NULL,'2014-05-02 05:33:31','2014-05-02 05:33:31','127.0.0.1','127.0.0.1','james2@mercstudio.com',NULL,NULL,NULL,NULL,NULL,NULL,'2014-05-02 05:33:22','2014-05-02 05:33:31','810cbe4bcc8cd6d97067d170cc2194e120beef226c86f53a',NULL,NULL),
	(3,'899350569f1edf50c8558d5b613cb208c5a9a3f95d2da11664b4d21643f11bb501af6ab56e583c15282ae8d0ffec3c13012ffbaa0360683d70147bce3d1818a5','UnUSHwFzPJxLt7gs-DzY','james3@mercstudio.com',NULL,NULL,NULL,NULL,1,0,NULL,'2014-05-08 06:39:38','2014-05-08 06:39:38','127.0.0.1','127.0.0.1','james3@mercstudio.com',NULL,NULL,NULL,NULL,NULL,NULL,'2014-05-08 06:39:28','2014-05-08 06:39:38','9e02d576b25ead578f04ae88f20a52802915cfd5b77b2e78',NULL,NULL);

/*!40000 ALTER TABLE `spree_users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_variants
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_variants`;

CREATE TABLE `spree_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL DEFAULT '',
  `weight` decimal(8,2) DEFAULT '0.00',
  `height` decimal(8,2) DEFAULT NULL,
  `width` decimal(8,2) DEFAULT NULL,
  `depth` decimal(8,2) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `is_master` tinyint(1) DEFAULT '0',
  `product_id` int(11) DEFAULT NULL,
  `cost_price` decimal(8,2) DEFAULT NULL,
  `cost_currency` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `track_inventory` tinyint(1) DEFAULT '1',
  `tax_category_id` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spree_variants_on_product_id` (`product_id`),
  KEY `index_spree_variants_on_sku` (`sku`),
  KEY `index_spree_variants_on_tax_category_id` (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_variants` WRITE;
/*!40000 ALTER TABLE `spree_variants` DISABLE KEYS */;

INSERT INTO `spree_variants` (`id`, `sku`, `weight`, `height`, `width`, `depth`, `deleted_at`, `is_master`, `product_id`, `cost_price`, `cost_currency`, `position`, `track_inventory`, `tax_category_id`, `updated_at`)
VALUES
	(1,'abc001',0.00,NULL,NULL,NULL,NULL,1,1,10.00,'USD',1,1,NULL,'2014-05-08 15:08:13');

/*!40000 ALTER TABLE `spree_variants` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_zone_members
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_zone_members`;

CREATE TABLE `spree_zone_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zoneable_id` int(11) DEFAULT NULL,
  `zoneable_type` varchar(255) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_zone_members` WRITE;
/*!40000 ALTER TABLE `spree_zone_members` DISABLE KEYS */;

INSERT INTO `spree_zone_members` (`id`, `zoneable_id`, `zoneable_type`, `zone_id`, `created_at`, `updated_at`)
VALUES
	(1,72,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(2,10,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(3,76,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(4,94,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(5,155,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(6,13,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(7,164,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(8,217,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(9,167,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(10,20,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(11,111,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(12,175,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(13,24,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(14,29,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(15,98,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(16,180,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(17,182,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(18,44,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(19,206,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(20,46,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(21,211,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(22,135,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(23,56,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(24,207,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(25,210,'Spree::Country',1,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(26,49,'Spree::Country',2,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(27,204,'Spree::Country',2,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(28,68,'Spree::Country',3,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(29,192,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(30,7,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(31,64,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(32,120,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(33,81,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(34,60,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(35,160,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(36,110,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(37,84,'Spree::Country',3,'2014-05-08 16:06:25','2014-05-08 16:06:25'),
	(38,120,'Spree::Country',4,'2014-05-08 16:13:18','2014-05-08 16:13:18'),
	(40,120,'Spree::Country',5,'2014-05-08 16:14:12','2014-05-08 16:14:12');

/*!40000 ALTER TABLE `spree_zone_members` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table spree_zones
# ------------------------------------------------------------

DROP TABLE IF EXISTS `spree_zones`;

CREATE TABLE `spree_zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default_tax` tinyint(1) DEFAULT '0',
  `zone_members_count` int(11) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `spree_zones` WRITE;
/*!40000 ALTER TABLE `spree_zones` DISABLE KEYS */;

INSERT INTO `spree_zones` (`id`, `name`, `description`, `default_tax`, `zone_members_count`, `created_at`, `updated_at`)
VALUES
	(1,'EU_VAT','Countries that make up the EU VAT zone.',0,25,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(2,'North America','USA + Canada',0,2,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(3,'South East Asia','South east asia',0,10,'2014-05-08 16:06:24','2014-05-08 16:06:24'),
	(4,'East Malaysia','East',0,2,'2014-05-08 16:13:18','2014-05-08 16:13:18'),
	(5,'West Malaysia','West',0,1,'2014-05-08 16:13:18','2014-05-08 16:13:18');

/*!40000 ALTER TABLE `spree_zones` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
